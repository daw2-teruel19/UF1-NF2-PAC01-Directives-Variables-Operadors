<?php
echo "upper";
?>


    <p style="color: <?php echo $_COOKIE['fontcolor'];?>; font-family: <?php echo $_COOKIE['fontsize'];?>">
    <font size="<?php echo $_COOKIE[fontfamily];?>">
    <?php echo $_COOKIE["texto"];?>
    </p>


