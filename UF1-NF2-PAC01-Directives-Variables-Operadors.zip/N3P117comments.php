<?php

echo "
    <ul>
        <li>Create a cookie</li>
        <li>Display cookie data</li>
        <li>Custom css for users</li>
        <li>Show today's date</li>
        <li>Check time periods based on dates</li>
        <li>include pages</li>
        <li>insert the mailto option</li>
        <li>create conditions</li>
        <li>Track logins</li>
        <li>/li>
    </ul> 
    Doc: 9 
    Student: 7 
    Improvement: -";
    
?>