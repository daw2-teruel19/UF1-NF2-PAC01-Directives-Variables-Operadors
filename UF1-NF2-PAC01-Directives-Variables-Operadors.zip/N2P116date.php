<html>
 <head>
  <title>How many days in this month?</title>

 </head>
 <body>
<?php
date_default_timezone_set('Europe/Madrid');
$month = date('M');
$day = date('l');

if ($month ==  1) { echo '31'; }
if ($month ==  2) { echo '28 (unless it\'s a leap year)'; }
if ($month ==  3) { echo '31'; }
if ($month ==  4) { echo '30'; }
if ($month ==  5) { echo '31'; }
if ($month ==  6) { echo '30'; }
if ($month ==  7) { echo '31'; }
if ($month ==  8) { echo '31'; }
if ($month ==  9) { echo '30'; }
if ($month == 10) { echo '31'; }
if ($month == 11) { echo '30'; }
if ($month == 12) { echo '31'; }

$amonth = (date('n'))-1;
$aday = (date('d'))-1;
$lmonth = 12-(date('n'));
$lday = (date('t'))-(date('d'));


echo "Yesterday it was "; echo "$aday ";
echo "The previous month is "; echo "$amonth ";
echo "There are "; echo "$lday"; echo " days left in this month. ";
echo "There are "; echo "$lmonth"; echo " months left in the current year. ";


if ((date('n')) >= 12 && (date('n')) <=2) {
    echo "Good winter!";
    }
if ((date('n')) >=9 && (date('n')) <=11) {
    echo "Good autumn!";
}
if ((date('n')) >=5  && (date('n')) <=8) {
    echo "Good summer!";
}
if ((date('n')) >= 3 && (date('n')) <=7) {
    echo "Good spring!";
}
?>
 </body>
</html>


