<?php
echo "hola";
if (isset($_POST['submit'])){
    
    $fontfamily = $_POST['font-family'];
    $fontcolor = $_POST['font-color'];
    $fontsize = $_POST['font-size'];
    $texto = $_POST['texto'];
    
    echo $fontfamily;
    echo $fontcolor;
    echo $fontsize;
    echo $texto;
}

?>

<!DOCTYPE html>
<html>
<head>
<title></title>
</head>

<body>
<div>
    <p style="color: 
    <?php 
    echo $fontcolor
    ?>; 
    fontfamily: 
    <?php 
    echo $font-family;
    ?>
    <?php 
    echo $fontsize;
    ?>"">
    <?php 
    echo $texto;
    ?>
    </font>
    </p>
</div>
</body>

</html>