<?php
echo "hola";
if (isset($_POST['submit'])){
    
    setcookie ("fontfamily", $_POST['fontfamily'], time()+10);
    setcookie ("fontcolor", $_POST['fontcolor'], time()+10);
    setcookie ("fontsize", $_POST['fontsize'], time()+10);
    setcookie ("texto", $_POST['texto'], time()+10);
  

    
    echo $fontfamily;
    echo $fontcolor;
    echo $fontsize;
    echo $texto;
}

?>

<!DOCTYPE html>
<html>
<head>
<title></title>
</head>

<body>
<div>
    <p style="color: 
    <?php 
    echo $_POST['fontcolor'];
    ?>; 
    font-family: 
    <?php 
    echo $_POST['fontfamily'];
    ?> 
    font-size:
    <?php 
    echo $_POST['fontsize'];
    ?>
    <?php 
    echo $_POST['texto'];
    ?>
    </font>
    </p>
</div>
</body>

</html>