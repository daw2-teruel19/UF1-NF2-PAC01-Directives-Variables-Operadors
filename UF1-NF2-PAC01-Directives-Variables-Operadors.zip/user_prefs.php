<?php

?>
<html>
 <head>
  <title>Please Log In</title>
  <?php include "N2Pfooter.php";?>

 </head>
 <body>
    </form>
  <form method="post" action="colors.php">
   <p>Select font:
   <input type="text" name="fontfamily"/>
   </p>
    <p>Select color:
    <input type="color" name="fontcolor"/>
   </p>
   <p>Select font size:
   <input type=number name="fontsize">
   </p>
   <p>Your text here:
   <textarea name="texto"></textarea>
   </p>
    <p>
    <input type="submit" name="submit" value="Submit"/>
   </p>
   <p>
   <a href="vercookie.php">Ver cookie</a>
   </p>
  </form>
 </body>
</html>