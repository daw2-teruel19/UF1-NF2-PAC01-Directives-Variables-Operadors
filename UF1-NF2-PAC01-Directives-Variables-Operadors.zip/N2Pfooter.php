<div style="text-align: center">
<p >Developed by <a href="mailto:quimtf91@gmail.com">quim teruel</a></p>

</div>