<?php

function display_times ($num_times){
    echo '<h3>'.$num_times.'sessions so far </h3>';
    }
    
    
$num_times = 1;
if (isset($_COOKIE['num_times'])){
    $num_times = $_COOKIE['num_times'] +1;
}

setcookie('num_times', $num_times, time()+60);
?>
<html>
<head>
<title>Page Title</title>
</head>
<body>
<?php display_times($num_times);?>
</body>
</html>

<form method="POST" action="cookieb.php">
Color: <input type="color" name="fontcolor"><br>
Tamaño: <input type="number" name="fontsize"><br>
Fuente: <input type="text" name="fontfamily"><br>
<textarea name="texto"></textarea><br>
<input type="submit" name="submit"><br>
<input type="checkbox" name="yes" value="yes" checked> Save cookie?<br><br>
<a href="vercookie.php">Mostrar</a>