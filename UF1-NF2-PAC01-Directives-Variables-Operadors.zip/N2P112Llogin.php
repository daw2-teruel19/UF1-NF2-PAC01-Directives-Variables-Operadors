<?php
session_unset();
?>
<html>
 <head>
  <title>Please Log In</title>
  <?php include "N2Pfooter.php";?>
    <?php include "N2P116date.php";?>
 </head>
 <body>
  <form method="post" action="N2P10Quim.php">
   <p>Enter your username: 
    <input type="text" name="user"/>
   </p>
    <p>Enter your nickname: 
    <input type="text" name="nick"/>
   </p>
   <p>Enter your password: 
    <input type="password" name="pass"/>
   </p>
    <p>
    <input type="submit" name="submit" value="Submit"/>
   </p>
  </form>
  <form method="post" action="colors.php">
   <p>Select font:
   <input type="text" name="font-family"/>
   </p>
    <p>Select color:
    <input type="color" name="font-color"/>
   </p>
   <p>Select font size:
   <input type=number name="font-size">
   </p>
   <p>Your text here:
   <textarea name="texto"></textarea>
   </p>
    <p>
    <input type="submit" name="submit" value="Submit"/>
   </p>
  </form>
 </body>
</html>




